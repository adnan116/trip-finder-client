export interface Property {
  ID: string;
  GeoInfo: {
    Lat: string;
    Lng: string;
    City: string;
    Country: string;
    Display: string;
  };
  Property: {
    PropertyName: string;
    PropertyType: string;
    Price: number;
    StarRating: number;
    FeatureImage: string;
    Counts: {
      Bedroom: number;
      Bathroom: number;
    };
    Amenities: {
      [key: string]: string;
    };
  };
}

export const sampleProperties: Property[] = [
  {
    ID: "EP-17350009",
    GeoInfo: {
      Lat: "23.80112",
      Lng: "90.41445",
      City: "Dhaka",
      Country: "Bangladesh",
      Display: "Dhaka, Dhaka, Bangladesh"
    },
    Property: {
      PropertyName: "White House Guest House",
      PropertyType: "House",
      Price: 41.4,
      StarRating: 3,
      FeatureImage: "https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      Counts: {
        Bedroom: 1,
        Bathroom: 1
      },
      Amenities: {
        "1": "Air Conditioner",
        "2": "Balcony/Terrace",
        "3": "Bedding/Linens",
        "4": "Breakfast",
        "7": "Internet"
      }
    }
  },
  {
    ID: "EP-17350010",
    GeoInfo: {
      Lat: "23.81234",
      Lng: "90.42445",
      City: "Dhaka",
      Country: "Bangladesh",
      Display: "Gulshan, Dhaka, Bangladesh"
    },
    Property: {
      PropertyName: "Luxury Villa Gulshan",
      PropertyType: "Villa",
      Price: 120.5,
      StarRating: 4,
      FeatureImage: "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      Counts: {
        Bedroom: 3,
        Bathroom: 2
      },
      Amenities: {
        "1": "Air Conditioner",
        "2": "Balcony/Terrace",
        "7": "Internet",
        "8": "Kitchen",
        "9": "Laundry"
      }
    }
  }
];