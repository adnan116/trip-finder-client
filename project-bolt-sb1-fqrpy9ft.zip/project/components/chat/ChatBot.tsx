'use client';

import { useState } from 'react';
import { MessageCircle, Image as ImageIcon, Mic, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import PropertyMap from '@/components/chat/PropertyMap';
import WeatherInfo from '@/components/chat/WeatherInfo';

export default function ChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle message submission
    setMessage('');
  };

  return (
    <>
      <Button
        className="fixed bottom-4 right-4 rounded-full h-12 w-12 p-0"
        onClick={() => setIsOpen(true)}
      >
        <MessageCircle className="h-6 w-6" />
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="sm:max-w-[800px] h-[80vh]">
          <DialogHeader>
            <DialogTitle>Property Assistant</DialogTitle>
          </DialogHeader>

          <div className="flex flex-col h-full space-y-4">
            <PropertyMap />
            <WeatherInfo />

            <div className="flex-grow overflow-y-auto p-4 space-y-4">
              {/* Chat messages will go here */}
            </div>

            <form onSubmit={handleSubmit} className="flex items-center space-x-2">
              <Button
                type="button"
                size="icon"
                variant="ghost"
                className="shrink-0"
              >
                <ImageIcon className="h-5 w-5" />
              </Button>
              <Button
                type="button"
                size="icon"
                variant="ghost"
                className="shrink-0"
              >
                <Mic className="h-5 w-5" />
              </Button>
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Type your message..."
                className="flex-grow"
              />
              <Button type="submit" size="icon" className="shrink-0">
                <Send className="h-5 w-5" />
              </Button>
            </form>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}