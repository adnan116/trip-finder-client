'use client';

import { useState } from 'react';
import { GoogleMap, useLoadScript, Marker, InfoWindow } from '@react-google-maps/api';
import { Star, Bed, Bath } from 'lucide-react';
import { sampleProperties, type Property } from '@/lib/sampleProperties';

const defaultCenter = {
  lat: 23.80112,
  lng: 90.41445
};

export default function PropertyMap() {
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  
  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY || '',
  });

  if (loadError) {
    return (
      <div className="w-full h-[300px] flex items-center justify-center bg-muted">
        <p className="text-muted-foreground">Error loading maps</p>
      </div>
    );
  }

  if (!isLoaded) {
    return (
      <div className="w-full h-[300px] flex items-center justify-center bg-muted">
        <p className="text-muted-foreground">Loading maps...</p>
      </div>
    );
  }

  return (
    <GoogleMap
      mapContainerClassName="w-full h-[300px]"
      center={defaultCenter}
      zoom={12}
      options={{
        disableDefaultUI: true,
        zoomControl: true,
      }}
    >
      {sampleProperties.map((property) => (
        <Marker
          key={property.ID}
          position={{
            lat: parseFloat(property.GeoInfo.Lat),
            lng: parseFloat(property.GeoInfo.Lng)
          }}
          onClick={() => setSelectedProperty(property)}
        />
      ))}

      {selectedProperty && (
        <InfoWindow
          position={{
            lat: parseFloat(selectedProperty.GeoInfo.Lat),
            lng: parseFloat(selectedProperty.GeoInfo.Lng)
          }}
          onCloseClick={() => setSelectedProperty(null)}
        >
          <div className="max-w-[300px]">
            <img
              src={selectedProperty.Property.FeatureImage}
              alt={selectedProperty.Property.PropertyName}
              className="w-full h-[150px] object-cover rounded-t-lg"
            />
            <div className="p-3">
              <h3 className="font-semibold text-lg mb-1">
                {selectedProperty.Property.PropertyName}
              </h3>
              <p className="text-sm text-muted-foreground mb-2">
                {selectedProperty.GeoInfo.Display}
              </p>
              <div className="flex items-center gap-4 mb-2">
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 text-yellow-400" />
                  <span className="text-sm">{selectedProperty.Property.StarRating}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Bed className="h-4 w-4" />
                  <span className="text-sm">{selectedProperty.Property.Counts.Bedroom}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Bath className="h-4 w-4" />
                  <span className="text-sm">{selectedProperty.Property.Counts.Bathroom}</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-sm">
                  <span className="font-semibold">${selectedProperty.Property.Price}</span>
                  <span className="text-muted-foreground">/night</span>
                </div>
                <div className="text-xs text-muted-foreground">
                  {selectedProperty.Property.PropertyType}
                </div>
              </div>
            </div>
          </div>
        </InfoWindow>
      )}
    </GoogleMap>
  );
}